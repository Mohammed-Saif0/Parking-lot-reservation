from django.contrib import admin

from homepage.models import Vehicle

# Register your models here.
admin.site.register(Vehicle)